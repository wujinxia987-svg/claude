package com.personal.aiclient

import android.Manifest
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.location.LocationManager
import android.os.Build
import android.provider.CalendarContract
import android.provider.Settings
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.annotation.Permission
import com.getcapacitor.annotation.PermissionCallback
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@CapacitorPlugin(name="DeviceMeta", permissions=[
    Permission(strings=[Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION], alias="location"),
    Permission(strings=[Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR], alias="calendar")
])
class DeviceMetaPlugin : Plugin() {
    @com.getcapacitor.PluginMethod
    fun getBasic(call: PluginCall) {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val o = JSObject()
        o.put("time", System.currentTimeMillis())
        o.put("iso", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.getDefault()).format(Date()))
        o.put("battery", bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY))
        o.put("device", Build.MODEL)
        o.put("manufacturer", Build.MANUFACTURER)
        o.put("android", Build.VERSION.RELEASE)
        o.put("sdk", Build.VERSION.SDK_INT)
        o.put("timezone", java.util.TimeZone.getDefault().id)
        call.resolve(o)
    }
    @com.getcapacitor.PluginMethod
    fun openUsageAccess(call: PluginCall) { context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)); call.resolve() }
    @com.getcapacitor.PluginMethod
    fun getScreenTime(call: PluginCall) {
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis(); val start = end - 24 * 60 * 60 * 1000L
        val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end)
        var total = 0L
        stats?.forEach { total += it.totalTimeInForeground }
        val o = JSObject(); o.put("minutes", total / 60000L); o.put("usageAccess", !stats.isNullOrEmpty()); call.resolve(o)
    }

    @com.getcapacitor.PluginMethod
    fun getLocation(call: PluginCall) {
        if (getPermissionState("location").name != "GRANTED") { call.reject("Location permission required"); return }
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
        var best: android.location.Location? = null
        for (provider in providers) {
            try { val x = lm.getLastKnownLocation(provider); if (x != null && (best == null || x.time > best!!.time)) best = x } catch (_: SecurityException) {}
        }
        if (best == null) { call.reject("No recent location available"); return }
        val o = JSObject(); o.put("latitude", best.latitude); o.put("longitude", best.longitude); o.put("accuracy", best.accuracy); o.put("time", best.time); call.resolve(o)
    }

    @com.getcapacitor.PluginMethod
    fun getCalendarToday(call: PluginCall) {
        if (getPermissionState("calendar").name != "GRANTED") { call.reject("Calendar permission required"); return }
        val start = java.util.Calendar.getInstance().apply { set(java.util.Calendar.HOUR_OF_DAY,0); set(java.util.Calendar.MINUTE,0); set(java.util.Calendar.SECOND,0); set(java.util.Calendar.MILLISECOND,0) }.timeInMillis
        val end = start + 24 * 60 * 60 * 1000L
        val uri = CalendarContract.Instances.CONTENT_URI.buildUpon().appendPath(start.toString()).appendPath(end.toString()).build()
        val events = org.json.JSONArray()
        context.contentResolver.query(uri, arrayOf(CalendarContract.Instances.TITLE,CalendarContract.Instances.BEGIN,CalendarContract.Instances.END,CalendarContract.Instances.ALL_DAY), null, null, CalendarContract.Instances.BEGIN+" ASC")?.use { c ->
            val ti=c.getColumnIndex(CalendarContract.Instances.TITLE); val bi=c.getColumnIndex(CalendarContract.Instances.BEGIN); val ei=c.getColumnIndex(CalendarContract.Instances.END); val ai=c.getColumnIndex(CalendarContract.Instances.ALL_DAY)
            while(c.moveToNext()){ val o=org.json.JSONObject(); o.put("title",if(ti>=0)c.getString(ti) else ""); o.put("begin",if(bi>=0)c.getLong(bi) else 0); o.put("end",if(ei>=0)c.getLong(ei) else 0); o.put("allDay",ai>=0 && c.getInt(ai)!=0); events.put(o) }
        }
        val out=JSObject();out.put("events",events);call.resolve(out)
    }

    @com.getcapacitor.PluginMethod
    fun requestLocation(call: PluginCall) { requestPermissionForAlias("location", call, "locationPerm") }
    @PermissionCallback
    private fun locationPerm(call: PluginCall) { if (getPermissionState("location").name == "GRANTED") call.resolve() else call.reject("Location permission denied") }
    @com.getcapacitor.PluginMethod
    fun requestCalendar(call: PluginCall) { requestPermissionForAlias("calendar", call, "calendarPerm") }
    @PermissionCallback
    private fun calendarPerm(call: PluginCall) { if (getPermissionState("calendar").name == "GRANTED") call.resolve() else call.reject("Calendar permission denied") }
    @com.getcapacitor.PluginMethod
    fun openCalendar(call: PluginCall) { context.startActivity(Intent(Intent.ACTION_VIEW, CalendarContract.CONTENT_URI)); call.resolve() }
}
