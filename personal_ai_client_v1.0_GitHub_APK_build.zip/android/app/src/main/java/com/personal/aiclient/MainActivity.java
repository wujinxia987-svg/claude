package com.personal.aiclient;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
