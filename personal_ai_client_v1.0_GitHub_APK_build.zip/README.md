# Personal AI Client v1.0

## 手机云编译 APK

这个项目已经包含 Android 工程目录，并配置了手动 GitHub Actions 云编译。

1. 把项目根目录的所有文件上传到 GitHub 仓库。
2. 打开仓库的 **Actions**。
3. 选择 **Build Android APK**。
4. 点击 **Run workflow**。
5. 等待构建完成。
6. 在构建页面底部 **Artifacts** 下载 `personal-ai-client-debug-apk`。
7. 解压后安装 APK。

不会自动编译；只有你手动点击 Run workflow 才会运行。

构建使用 Capacitor 7.4.3、Android SDK 35、JDK 21 和 Gradle 8.10.2。
