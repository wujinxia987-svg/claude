# Personal AI Client v3

A GitHub-Actions-buildable Capacitor Android AI client with a Claude-inspired mobile UI and a RikkaHub-inspired feature architecture.

## Included
- polished mobile chat UI with light/dark themes
- multiple providers: OpenAI-compatible, Anthropic, Gemini
- streaming chat for supported endpoints
- assistant profiles and system prompts
- persistent chat history and message branching/regeneration
- Markdown rendering
- memory store and automatic memory hints
- MCP server registry + Streamable HTTP initialize/tools-list flow
- device Meta bridge: time, battery, device, calendar permission, location permission, screen-time settings
- local notifications for proactive-chat scheduling
- WebView speech recognition + speech synthesis voice mode
- ZIP backup/restore for chats, memory, assistants, providers and MCP configuration
- attachment registry for images/documents
- Workspace data model and tool boundary

## Build
The supplied workflow expects `personal_ai_client_v1.0_GitHub_APK_build.zip` in the repository root and runs `npm install`, `npm run build`, `npx cap sync android`, then Gradle.

This project intentionally uses a real Vite build. Do not replace it with a raw `src -> dist` copy: Capacitor/npm modules must be bundled for Android WebView.

## Notes
MCP servers must allow requests from the app/WebView (CORS) unless routed through a native proxy. Android system permissions are requested only when the corresponding feature is used. A fully privileged Linux/proot workspace requires a native sandbox backend; the UI and data/tool boundary are included here so that backend can be added without changing the chat model.

RikkaHub reference: its current feature set includes multi-provider AI, multimodal input, MCP, Markdown, branching, web search, prompt variables, assistants, memory, image generation, speech and backups. See the official repository for the original implementation and AGPL-3.0 license.
