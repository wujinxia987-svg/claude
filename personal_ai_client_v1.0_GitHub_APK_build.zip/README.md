# Personal AI Client v1.2

## 手机云编译 APK

1. 把项目根目录所有文件（或本 ZIP）上传到 GitHub 仓库。
2. 打开 **Actions** → **Build Android APK** → **Run workflow**。
3. 构建完成后在 Artifacts 下载 APK 安装。

构建：Capacitor 7.4.3、Android SDK 35、JDK 21、Gradle 8.10.2。

## v1.2 更新

- Claude 风格 UI + 浅色/深色/跟随系统
- 多服务商预设：OpenAI / Anthropic / DeepSeek / OpenRouter / 硅基流动 / 自定义
- 顶部模型快速切换
- 消息操作：复制、重新生成、朗读、分享
- 全部中文界面
- 保留：多会话、记忆、导入 Operit ZIP、流式输出、元数据注入等
