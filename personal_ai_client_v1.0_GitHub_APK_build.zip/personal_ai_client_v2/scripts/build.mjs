import {cp, mkdir, rm, access} from 'node:fs/promises';

await rm('dist', {recursive: true, force: true});
await mkdir('dist', {recursive: true});

// Copy the web source into dist.
await cp('src', 'dist', {recursive: true});

// public/ is optional. This keeps the GitHub Actions build from failing
// when the project has no public assets yet.
try {
  await access('public');
  await cp('public', 'dist', {recursive: true});
} catch (error) {
  if (error?.code !== 'ENOENT') throw error;
  console.log('public/ not found; continuing without public assets.');
}
