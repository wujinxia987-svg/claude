package com.personal.aiclient

import android.Manifest
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.CalendarContract
import android.provider.Settings
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.annotation.Permission
import com.getcapacitor.annotation.PermissionCallback
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@CapacitorPlugin(name="DeviceMeta", permissions=[
  Permission(strings=[Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION], alias="location"),
  Permission(strings=[Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR], alias="calendar")
])
class DeviceMetaPlugin: Plugin() {
  @com.getcapacitor.PluginMethod
  fun getBasic(call: PluginCall) {
    val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    val o = JSObject()
    o.put("time", System.currentTimeMillis())
    o.put("iso", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.getDefault()).format(Date()))
    o.put("battery", bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY))
    o.put("device", Build.MODEL)
    o.put("manufacturer", Build.MANUFACTURER)
    o.put("android", Build.VERSION.RELEASE)
    o.put("timezone", java.util.TimeZone.getDefault().id)
    call.resolve(o)
  }
  @com.getcapacitor.PluginMethod
  fun openUsageAccess(call: PluginCall) { context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)); call.resolve() }
  @com.getcapacitor.PluginMethod
  fun getScreenTime(call: PluginCall) {
    val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    val end=System.currentTimeMillis(); val start=end-24*60*60*1000L
    val stats=usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY,start,end)
    var total=0L; stats?.forEach { total += it.totalTimeInForeground }
    val o=JSObject(); o.put("minutes", total/60000L); o.put("usageAccess", stats?.isNotEmpty()==true); call.resolve(o)
  }
  @com.getcapacitor.PluginMethod
  fun requestLocation(call: PluginCall) { requestPermissionForAlias("location",call,"locationPerm") }
  @PermissionCallback
  private fun locationPerm(call: PluginCall) { if (hasRequiredPermissions("location")) call.resolve() else call.reject("Location permission denied") }
  @com.getcapacitor.PluginMethod
  fun requestCalendar(call: PluginCall) { requestPermissionForAlias("calendar",call,"calendarPerm") }
  @PermissionCallback
  private fun calendarPerm(call: PluginCall) { if (hasRequiredPermissions("calendar")) call.resolve() else call.reject("Calendar permission denied") }
  @com.getcapacitor.PluginMethod
  fun openCalendar(call: PluginCall) { context.startActivity(Intent(Intent.ACTION_VIEW, CalendarContract.CONTENT_URI)); call.resolve() }
}
