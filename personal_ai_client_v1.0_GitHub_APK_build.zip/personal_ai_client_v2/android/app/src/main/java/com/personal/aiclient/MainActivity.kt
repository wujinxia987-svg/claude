package com.personal.aiclient

import android.os.Bundle
import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    registerPlugin(DeviceMetaPlugin::class.java)
    super.onCreate(savedInstanceState)
  }
}
