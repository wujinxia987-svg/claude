# Personal AI Client 2.0

Capacitor Android project designed to work with the supplied GitHub Actions workflow.

It provides a Claude-style mobile chat shell, light/dark theme, OpenAI-compatible API configuration, ZIP chat backup/import, local notifications, MCP server URL storage, and native device metadata/permission bridges for time, battery, calendar, location and usage access.

This package is an original implementation inspired by the requested feature set; it does not contain proprietary Claude source/assets and does not claim to be a complete source-level clone of RikkaHub.
