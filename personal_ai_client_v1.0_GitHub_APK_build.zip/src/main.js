import { marked } from 'marked';
import JSZip from 'jszip';
import './style.css';

const K = 'personal-ai-v1';
const D = {
  settings: {
    baseUrl: '',
    apiKey: '',
    model: 'claude',
    systemPrompt: '',
    temperature: 0.7,
    maxTokens: 4096,
    sttUrl: '',
    sttKey: '',
    sttModel: '',
    ttsUrl: '',
    ttsKey: '',
    ttsModel: '',
    ttsVoice: '',
    proactive: 'off',
    minGap: 30,
    quietStart: '23:00',
    quietEnd: '08:00',
    theme: 'light',
    meta: {
      time: true,
      timezone: true,
      battery: true,
      network: true,
      app: true,
      device: true,
      audio: false,
      location: false,
    },
  },
  chats: [],
  memories: [],
};

let s = (() => {
  try {
    const raw = JSON.parse(localStorage.getItem(K));
    const merged = { ...D, ...raw, settings: { ...D.settings, ...(raw?.settings || {}) } };
    merged.settings.meta = { ...D.settings.meta, ...(raw?.settings?.meta || {}) };
    return merged;
  } catch {
    return structuredClone(D);
  }
})();

let cid = null;
let aborter = null;
let busy = false;

const save = () => localStorage.setItem(K, JSON.stringify(s));
const chat = () => s.chats.find((c) => c.id === cid);
const esc = (x) =>
  String(x ?? '').replace(
    /[&<>"']/g,
    (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]
  );

const $ = (sel) => document.querySelector(sel);

function applyTheme() {
  const t = s.settings.theme || 'light';
  document.documentElement.setAttribute('data-theme', t === 'system' ? (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light') : t);
}

function greeting() {
  const h = new Date().getHours();
  if (h < 6) return '夜深了，需要我帮忙吗？';
  if (h < 12) return '早上好，今天想聊点什么？';
  if (h < 14) return '中午好，有什么可以帮你的？';
  if (h < 18) return '下午好，想从哪里开始？';
  if (h < 22) return '晚上好，今天过得怎么样？';
  return '夜深了，需要我帮忙吗？';
}

const STAR_SVG = `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.5c.4 2.8 1.6 4.8 3.5 6.2 1.9 1.4 4.1 2.1 6.5 2.3-2.4.2-4.6.9-6.5 2.3-1.9 1.4-3.1 3.4-3.5 6.2-.4-2.8-1.6-4.8-3.5-6.2C6.6 11.9 4.4 11.2 2 11c2.4-.2 4.6-.9 6.5-2.3C10.4 7.3 11.6 5.3 12 2.5z"/></svg>`;

function meta() {
  const d = new Date();
  const m = s.settings.meta || {};
  return {
    time: m.time ? d.toISOString() : undefined,
    localTime: m.time ? d.toLocaleString() : undefined,
    timezone: m.timezone ? Intl.DateTimeFormat().resolvedOptions().timeZone : undefined,
    weekday: m.time ? d.toLocaleDateString(undefined, { weekday: 'long' }) : undefined,
    battery: undefined,
    online: m.network ? navigator.onLine : undefined,
    app: m.app ? { foreground: document.visibilityState === 'visible', idleSeconds: 0 } : undefined,
    device: m.device
      ? { platform: navigator.platform, language: navigator.language, screen: `${screen.width}x${screen.height}` }
      : undefined,
  };
}

async function battery() {
  try {
    const b = await navigator.getBattery();
    return { level: Math.round(b.level * 100) + '%', charging: b.charging };
  } catch {
    return undefined;
  }
}

async function buildSystem() {
  let x = s.settings.systemPrompt || '';
  const mm = meta();
  mm.battery = s.settings.meta.battery ? await battery() : undefined;
  if (s.memories?.length) {
    x +=
      '\n\n长期记忆参考：\n' +
      s.memories
        .slice(0, 80)
        .map((m) => `【${m.title}】\n${m.content}`)
        .join('\n\n');
  }
  x += '\n\n<client_meta>\n' + JSON.stringify(mm, null, 2) + '\n</client_meta>';
  return x;
}

async function callAPI(messages, onToken) {
  const st = s.settings;
  const url = (st.baseUrl || '').replace(/\/+$/, '') + '/chat/completions';
  if (!st.baseUrl) throw Error('请先在设置中填写 Base URL');
  const r = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(st.apiKey ? { Authorization: `Bearer ${st.apiKey}` } : {}),
    },
    body: JSON.stringify({
      model: st.model,
      messages,
      temperature: Number(st.temperature),
      max_tokens: Number(st.maxTokens),
      stream: true,
    }),
    signal: aborter?.signal,
  });
  if (!r.ok) throw Error(`HTTP ${r.status}: ${(await r.text()).slice(0, 300)}`);
  const rd = r.body.getReader();
  const td = new TextDecoder();
  let buf = '';
  while (1) {
    const q = await rd.read();
    if (q.done) break;
    buf += td.decode(q.value, { stream: true });
    const ls = buf.split(/\r?\n/);
    buf = ls.pop() || '';
    for (const l of ls) {
      if (!l.startsWith('data:')) continue;
      const p = l.slice(5).trim();
      if (p === '[DONE]') return;
      try {
        const t = JSON.parse(p).choices?.[0]?.delta?.content;
        if (t) onToken(t);
      } catch {}
    }
  }
}

function newChat() {
  const c = { id: crypto.randomUUID(), title: '新的聊天', messages: [], createdAt: Date.now() };
  s.chats.unshift(c);
  cid = c.id;
  save();
  render();
}

function field(k, n, p, pass = false) {
  return `<label>${n}<input id="f-${k}" ${pass ? 'type="password"' : ''} value="${esc(s.settings[k] ?? '')}" placeholder="${esc(p || '')}"></label>`;
}

function render() {
  applyTheme();
  if (!s.chats.length) newChat();
  if (!cid) cid = s.chats[0].id;
  const c = chat();
  const theme = s.settings.theme || 'light';

  document.querySelector('#app').innerHTML = `
<div class="app">
  <div id="shade"></div>
  <aside id="drawer">
    <div class="drawer-header">
      <span class="drawer-title">Personal AI</span>
      <button class="icon-btn" id="close" aria-label="关闭">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
      </button>
    </div>
    <button class="new-chat-btn" id="new">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>
      新建聊天
    </button>
    <div class="history">
      ${s.chats
        .map(
          (x) => `
        <div class="chat-row ${x.id === cid ? 'sel' : ''}" data-c="${x.id}">
          <span class="chat-row-title">${esc(x.title)}</span>
          <button class="chat-row-more" data-d="${x.id}" aria-label="更多">···</button>
        </div>`
        )
        .join('')}
    </div>
    <div class="drawer-footer">
      <button id="set">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="3"/><path d="M12 1v2M12 21v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M1 12h2M21 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4"/></svg>
        设置
      </button>
      <button id="imp">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3"/></svg>
        导入 Operit ZIP
      </button>
    </div>
  </aside>

  <main>
    <header class="top">
      <div class="top-left">
        <button class="icon-btn" id="menu" aria-label="菜单">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
        </button>
      </div>
      <span class="model-label">${esc(s.settings.model || 'AI')}</span>
      <div class="top-right"></div>
    </header>

    <section id="content">
      ${
        c.messages.length
          ? `<div class="messages">${c.messages
              .map(
                (m) => `
            <article class="msg ${m.role}">
              ${m.role === 'assistant' ? `<div class="msg-avatar">${STAR_SVG}</div>` : ''}
              <div class="bubble">${m.role === 'assistant' ? marked.parse(m.content) : esc(m.content).replace(/\n/g, '<br>')}</div>
            </article>`
              )
              .join('')}</div>`
          : `<div class="welcome">
              <div class="claude-star">${STAR_SVG}</div>
              <h1>${greeting()}</h1>
              <p>我是你的个人 AI 助手</p>
            </div>`
      }
    </section>

    <div class="composer">
      <div class="composer-inner">
        <textarea id="input" rows="1" placeholder="给 AI 发消息…"></textarea>
        <button class="send-btn" id="send" ${busy ? '' : ''} aria-label="发送">
          ${
            busy
              ? `<svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="6" width="12" height="12" rx="2"/></svg>`
              : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M12 19V5M5 12l7-7 7 7"/></svg>`
          }
        </button>
      </div>
      <small class="composer-hint">AI 可能会犯错，请核实重要信息</small>
    </div>
  </main>

  <section id="settings">
    <div class="settings-header">
      <button class="icon-btn" id="back" aria-label="返回">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <b>设置</b>
    </div>
    <div class="settings-body">
      <div class="section-label">外观</div>
      <div class="card">
        <div class="theme-row">
          <button class="theme-opt ${theme === 'light' ? 'active' : ''}" data-theme="light">浅色</button>
          <button class="theme-opt ${theme === 'dark' ? 'active' : ''}" data-theme="dark">深色</button>
          <button class="theme-opt ${theme === 'system' ? 'active' : ''}" data-theme="system">跟随系统</button>
        </div>
      </div>

      <div class="section-label">API</div>
      <div class="card">
        ${field('baseUrl', 'Base URL', 'https://api.example.com/v1')}
        ${field('apiKey', 'API Key', 'sk-...', true)}
        ${field('model', '模型', 'claude')}
      </div>

      <div class="section-label">聊天</div>
      <div class="card">
        ${field('systemPrompt', 'System Prompt', '')}
        ${field('temperature', 'Temperature', '0.7')}
        ${field('maxTokens', 'Max Tokens', '4096')}
      </div>

      <div class="section-label">语音 API</div>
      <div class="card">
        ${field('sttUrl', 'STT URL', '')}
        ${field('sttKey', 'STT Key', '', true)}
        ${field('sttModel', 'STT 模型', '')}
        ${field('ttsUrl', 'TTS URL', '')}
        ${field('ttsKey', 'TTS Key', '', true)}
        ${field('ttsModel', 'TTS 模型', '')}
        ${field('ttsVoice', 'TTS 音色', '')}
      </div>

      <div class="section-label">主动模式</div>
      <div class="card">
        <label>状态
          <select id="f-proactive">
            <option value="off">关闭</option>
            <option value="on">开启</option>
          </select>
        </label>
        ${field('minGap', '最小间隔（分钟）', '30')}
        ${field('quietStart', '安静开始', '23:00')}
        ${field('quietEnd', '安静结束', '08:00')}
      </div>

      <div class="section-label">上下文元数据</div>
      <div class="card">
        <div class="meta-row">
          ${['time', 'timezone', 'battery', 'network', 'app', 'device', 'audio', 'location']
            .map(
              (m) =>
                `<label><input type="checkbox" class="meta" data-m="${m}" ${s.settings.meta[m] ? 'checked' : ''}> ${
                  { time: '时间', timezone: '时区', battery: '电量', network: '网络', app: '前台状态', device: '设备', audio: '音频', location: '位置' }[m]
                }</label>`
            )
            .join('')}
        </div>
      </div>

      <div class="section-label">数据</div>
      <div class="card">
        <button class="action-btn" id="export">导出备份 JSON</button>
        <button class="action-btn danger" id="cm">清空全部记忆</button>
        <button class="action-btn danger" id="cc">清空全部聊天</button>
      </div>
      <p class="hint">数据仅保存在本机。导入 Operit ZIP 可从侧边栏底部入口进入。</p>
      <input type="file" id="zip" accept=".zip" style="display:none">
    </div>
  </section>
</div>`;

  bind();
  const el = $('#content');
  if (el) el.scrollTop = el.scrollHeight;
}

function bind() {
  const openDrawer = () => {
    $('#drawer')?.classList.add('open');
    $('#shade')?.classList.add('show');
  };
  const closeDrawer = () => {
    $('#drawer')?.classList.remove('open');
    $('#shade')?.classList.remove('show');
  };

  $('#menu')?.addEventListener('click', openDrawer);
  $('#close')?.addEventListener('click', closeDrawer);
  $('#shade')?.addEventListener('click', closeDrawer);
  $('#new')?.addEventListener('click', () => {
    newChat();
    closeDrawer();
  });

  document.querySelectorAll('.chat-row').forEach((row) => {
    row.addEventListener('click', (e) => {
      if (e.target.closest('[data-d]')) return;
      cid = row.dataset.c;
      save();
      render();
      closeDrawer();
    });
  });

  document.querySelectorAll('[data-d]').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = btn.dataset.d;
      if (!confirm('删除这个聊天？')) return;
      s.chats = s.chats.filter((c) => c.id !== id);
      if (cid === id) cid = s.chats[0]?.id || null;
      save();
      render();
    });
  });

  $('#set')?.addEventListener('click', () => {
    closeDrawer();
    $('#settings')?.classList.add('show');
  });
  $('#back')?.addEventListener('click', () => {
    $('#settings')?.classList.remove('show');
    render();
  });
  $('#imp')?.addEventListener('click', () => {
    closeDrawer();
    $('#zip')?.click();
  });

  $('#send')?.addEventListener('click', () => {
    if (busy) {
      aborter?.abort();
      return;
    }
    send();
  });

  const input = $('#input');
  input?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  });
  input?.addEventListener('input', () => {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 140) + 'px';
  });

  document.querySelectorAll('.theme-opt').forEach((btn) => {
    btn.addEventListener('click', () => {
      s.settings.theme = btn.dataset.theme;
      save();
      applyTheme();
      document.querySelectorAll('.theme-opt').forEach((b) => b.classList.toggle('active', b.dataset.theme === s.settings.theme));
    });
  });

  [
    'baseUrl',
    'apiKey',
    'model',
    'systemPrompt',
    'temperature',
    'maxTokens',
    'sttUrl',
    'sttKey',
    'sttModel',
    'ttsUrl',
    'ttsKey',
    'ttsModel',
    'ttsVoice',
    'minGap',
    'quietStart',
    'quietEnd',
  ].forEach((k) => {
    $(`#f-${k}`)?.addEventListener('change', (e) => {
      s.settings[k] = e.target.value;
      save();
    });
  });

  const pro = $('#f-proactive');
  if (pro) {
    pro.value = s.settings.proactive;
    pro.onchange = (e) => {
      s.settings.proactive = e.target.value;
      save();
    };
  }

  document.querySelectorAll('.meta').forEach((e) => {
    e.onchange = () => {
      s.settings.meta[e.dataset.m] = e.checked;
      save();
    };
  });

  $('#zip').onchange = async (e) => {
    try {
      const r = await importZip(e.target.files[0]);
      s.chats = [...r.chats, ...s.chats];
      s.memories = [...s.memories, ...r.memories];
      save();
      cid = r.chats[0]?.id || cid;
      alert(`导入完成：${r.chats.length} 个聊天，${r.memories.length} 条记忆`);
      render();
    } catch (x) {
      alert('导入失败：' + x.message);
    }
    e.target.value = '';
  };

  $('#export')?.addEventListener('click', () =>
    download('ai-client-backup.json', JSON.stringify({ chats: s.chats, memories: s.memories }, null, 2))
  );
  $('#cm')?.addEventListener('click', () => {
    if (!confirm('确定清空全部记忆？')) return;
    s.memories = [];
    save();
    alert('记忆已清空');
  });
  $('#cc')?.addEventListener('click', () => {
    if (!confirm('确定清空全部聊天？')) return;
    s.chats = [];
    save();
    newChat();
  });
}

async function send() {
  const i = $('#input');
  const t = i?.value.trim();
  if (!t || busy) return;
  const c = chat();
  c.messages.push({ role: 'user', content: t });
  if (c.title === '新的聊天') c.title = t.slice(0, 28);
  i.value = '';
  i.style.height = 'auto';
  const a = { role: 'assistant', content: '' };
  c.messages.push(a);
  busy = true;
  save();
  render();
  aborter = new AbortController();
  try {
    const sys = await buildSystem();
    const ms = [];
    if (sys) ms.push({ role: 'system', content: sys });
    ms.push(...c.messages.slice(0, -1));
    await callAPI(ms, (tok) => {
      a.content += tok;
      const box = document.querySelector('.msg.assistant:last-child .bubble');
      if (box) box.innerHTML = marked.parse(a.content);
      const el = $('#content');
      if (el) el.scrollTop = el.scrollHeight;
    });
  } catch (e) {
    if (e.name !== 'AbortError') a.content += `\n\n**请求失败：** ${esc(e.message)}`;
  } finally {
    busy = false;
    save();
    render();
  }
}

function download(n, t) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([t], { type: 'application/json' }));
  a.download = n;
  a.click();
}

const role = (v) => {
  const r = String(v?.role ?? v?.participant ?? v?.sender ?? v?.type ?? '').toLowerCase();
  return /user|human/.test(r) ? 'user' : /assistant|ai|claude|model/.test(r) ? 'assistant' : null;
};
const text = (v) => (typeof v === 'string' ? v : v?.content ?? v?.text ?? v?.message ?? '');

function walkMsgs(x, o = []) {
  if (!x) return o;
  if (Array.isArray(x)) {
    x.forEach((y) => walkMsgs(y, o));
    return o;
  }
  if (typeof x !== 'object') return o;
  const r = role(x);
  const t = text(x);
  if (r && String(t).trim()) {
    o.push({ role: r, content: String(t).trim(), timestamp: x.timestamp ?? x.createdAt ?? Date.now() });
    return o;
  }
  ['messages', 'conversation', 'conversations', 'turns', 'history', 'items', 'data'].forEach((k) => x[k] && walkMsgs(x[k], o));
  return o;
}

function walkMem(x, o = []) {
  if (!x) return o;
  if (Array.isArray(x)) {
    x.forEach((y) => walkMem(y, o));
    return o;
  }
  if (typeof x !== 'object') return o;
  if (Array.isArray(x.memories)) {
    x.memories.forEach((m) => {
      const t = text(m.content ?? m.text);
      if (String(t).trim())
        o.push({
          id: m.uuid || crypto.randomUUID(),
          title: m.title || '导入记忆',
          content: String(t).trim(),
          folderPath: m.folderPath || '',
          tags: m.tagNames || [],
          importance: m.importance ?? 0.5,
          credibility: m.credibility ?? 0.5,
        });
    });
    return o;
  }
  ['memory', 'memory_db', 'data', 'items'].forEach((k) => x[k] && walkMem(x[k], o));
  return o;
}

async function importZip(file) {
  if (!file) throw Error('没有选择文件');
  const z = await JSZip.loadAsync(file);
  const ch = [];
  const mem = [];
  const seen = new Set();
  for (const e of Object.values(z.files)) {
    if (e.dir || !/\.json$/i.test(e.name)) continue;
    let d;
    try {
      d = JSON.parse(await e.async('text'));
    } catch {
      continue;
    }
    const mm = walkMem(d);
    mem.push(...mm);
    const ms = walkMsgs(d);
    if (ms.length >= 2) {
      const sig = ms.map((x) => x.role + x.content.slice(0, 80)).join('|');
      if (!seen.has(sig)) {
        seen.add(sig);
        ch.push({
          id: crypto.randomUUID(),
          title: (ms.find((x) => x.role === 'user')?.content || e.name).slice(0, 28),
          messages: ms,
          createdAt: ms[0].timestamp,
        });
      }
    }
  }
  return { chats: ch, memories: mem };
}

window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
  if (s.settings.theme === 'system') applyTheme();
});

if (!s.chats.length) newChat();
else {
  cid = s.chats[0].id;
  render();
}
