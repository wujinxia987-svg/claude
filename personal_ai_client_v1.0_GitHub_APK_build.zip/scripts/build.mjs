import { rm, mkdir } from 'node:fs/promises';

// Vite performs the real production build and bundles npm dependencies
// (Capacitor plugins, JSZip, marked, etc.) so the Android WebView can load
// the application without unresolved bare module imports.
await rm('dist', { recursive: true, force: true });
await mkdir('dist', { recursive: true });

const { build } = await import('vite');
await build({
  configFile: './vite.config.js',
});
