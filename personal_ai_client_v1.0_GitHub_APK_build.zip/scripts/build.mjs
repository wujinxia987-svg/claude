import { rm } from 'node:fs/promises';
const { build } = await import('vite');
await rm('dist', { recursive:true, force:true });
await build({configFile:'./vite.config.js'});
