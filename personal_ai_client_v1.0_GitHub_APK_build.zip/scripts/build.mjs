import { build } from 'vite';

await build({
  configFile: './vite.config.js',
});
